"""Model Program use for PyQt 

Handles imports for custom classes 

"""
